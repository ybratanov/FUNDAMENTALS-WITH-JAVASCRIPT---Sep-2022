let undefinedVariable;
let undefinedVariable2 = undefined; 


console.log(undefinedVariable);
console.log(undefinedVariable2);

let arr = null;
console.log(arr);
