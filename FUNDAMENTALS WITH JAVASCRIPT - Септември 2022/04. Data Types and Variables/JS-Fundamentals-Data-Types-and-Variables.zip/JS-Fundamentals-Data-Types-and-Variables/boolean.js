let firstName = 'Pesho';

if (firstName) {
    console.log(firstName);
}
