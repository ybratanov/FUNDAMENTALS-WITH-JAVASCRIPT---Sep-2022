function join(first, second, delimiter) {
    let firstResult = first + delimiter + second;
    // let secondResult = `${first}${delimiter}${second}`;

    console.log(firstResult);
}

join('Jan',
'White',
'<->'
);
