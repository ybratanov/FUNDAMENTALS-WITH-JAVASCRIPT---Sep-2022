console.log(typeof '');
console.log(typeof 'Pesho');
console.log(typeof '50');
console.log(typeof 50);

let name = 'Pesho';
 
if (typeof name == 'string') {
    console.log('this is string');
}
